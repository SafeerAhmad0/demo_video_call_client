// src/routes/auth.ts
import { Router } from "express";
import { register, login, logout, me } from "../controllers/authController";
import { authenticateToken } from "../middleware/auth";
import {
  forgotPassword,
  resetPassword,
  validateResetToken,
} from "../controllers/passwordResetController";

const router = Router();

// Public routes
router.post("/register", register);
router.post("/login", login);
router.post("/logout", logout);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password", resetPassword);
router.get("/validate-reset-token/:token", validateResetToken);

// Protected routes
router.get("/me", authenticateToken, me);

export default router;
