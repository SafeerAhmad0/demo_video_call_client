// src/types/index.ts
import { Request } from "express";

export interface User {
  id: number;
  email: string;
  password: string;
  created_at: Date;
  updated_at: Date;
  reset_password_token?: string;
  reset_password_expires?: Date;
}

export interface AuthRequest extends Request {
  user?: {
    id: number;
    email: string;
  };
}

export interface RegisterRequest {
  email: string;
  password: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface ForgotPasswordRequest {
  email: string;
}

export interface ResetPasswordRequest {
  token: string;
  newPassword: string;
}
