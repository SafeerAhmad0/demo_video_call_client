// src/config/database.ts
import { Pool } from "pg";
import dotenv from "dotenv";

// Load environment variables from .env file
dotenv.config();

// Create a connection pool to PostgreSQL
const pool = new Pool({
  host: process.env.DB_HOST, // localhost
  port: parseInt(process.env.DB_PORT || "5432"), // 5432
  database: process.env.DB_NAME, // verifycall_db
  user: process.env.DB_USER, // verifycall_user
  password: process.env.DB_PASSWORD, // your password from .env
});

// Test the connection when the app starts
pool.connect((err, client, release) => {
  if (err) {
    console.error("❌ Error connecting to database:", err.stack);
    return;
  }
  console.log("✅ Database connected successfully");
  console.log(
    `📊 Connected to: ${process.env.DB_NAME} on ${process.env.DB_HOST}:${process.env.DB_PORT}`
  );
  release(); // Release the client back to the pool
});

// Handle pool errors
pool.on("error", (err) => {
  console.error("❌ Unexpected error on idle client:", err);
});

// Export the pool for use in other files
export default pool;
