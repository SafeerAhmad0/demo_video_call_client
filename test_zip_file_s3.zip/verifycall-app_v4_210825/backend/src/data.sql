-- Select all rows from 'TableName'

SELECT created_at, id, email ,password ,updated_at FROM users;
SELECT password   FROM users;