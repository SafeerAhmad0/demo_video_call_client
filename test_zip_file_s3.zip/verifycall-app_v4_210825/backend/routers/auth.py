from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.orm import Session
from database import get_db
from models import User
from schemas import UserCreate, UserLogin, UserResponse, AuthResponse
from auth import verify_password, get_password_hash, create_access_token
from dependencies import get_current_user, get_current_user_optional
from datetime import timedelta

router = APIRouter(prefix="/api/auth", tags=["authentication"])

@router.post("/register", response_model=AuthResponse)
async def register(user: UserCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(User).filter(User.email == user.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this email already exists"
        )
    
    # Validate password
    if len(user.password) < 6:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 6 characters long"
        )
    
    # Create new user
    hashed_password = get_password_hash(user.password)
    new_user = User(
        email=user.email,
        password=hashed_password
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Generate token
    access_token = create_access_token(data={"sub": str(new_user.id)})
    
    return {
        "message": "User created successfully",
        "user": {"id": new_user.id, "email": new_user.email},
        "access_token": access_token
    }

@router.post("/login", response_model=AuthResponse)
async def login(user: UserLogin, response: Response, db: Session = Depends(get_db)):
    # Find user
    db_user = db.query(User).filter(User.email == user.email).first()
    if not db_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Verify password
    if not verify_password(user.password, db_user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Generate token
    access_token = create_access_token(data={"sub": str(db_user.id)})
    
    # Set cookie
    response.set_cookie(
        key="accessToken",
        value=access_token,
        httponly=True,
        secure=False,  # Set to True in production
        samesite="strict",
        max_age=3600  # 1 hour
    )
    
    return {
        "message": "Login successful",
        "user": {"id": db_user.id, "email": db_user.email},
        "access_token": access_token
    }

@router.post("/logout")
async def logout(response: Response):
    response.delete_cookie("accessToken")
    return {"message": "Logged out successfully"}

@router.get("/me", response_model=UserResponse)
async def me(current_user: User = Depends(get_current_user)):
    return {"id": current_user.id, "email": current_user.email}
