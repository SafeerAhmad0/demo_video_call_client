from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from routers import auth, password_reset
import uvicorn
import os
from datetime import datetime, timezone

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Create FastAPI app
app = FastAPI(
    title="VerifyCall API",
    description="FastAPI backend for VerifyCall application",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost",
        "http://localhost:3000",
        "http://localhost:80"
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(password_reset.router)

# Health check endpoint
@app.get("/api/health")
async def health_check():
    return {
        "status": "OK",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "message": "VerifyCall API is running"
    }

# Root endpoint
@app.get("/")
async def root():
    return {"message": "Welcome to VerifyCall FastAPI Backend"}

# Global exception handler
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail}
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 5000)),
        reload=True
    )
from fastapi import FastAPI, Depends, Request
from pydantic import BaseModel
from datetime import datetime, timedelta
import jwt
import boto3
import psycopg2
from psycopg2.extras import RealDictCursor
import os

app = FastAPI()

# --- ENV VARIABLES ---
JWT_SECRET = os.getenv("JITSI_JWT_SECRET", "supersecret")
JITSI_APP_ID = os.getenv("JITSI_APP_ID", "my-app-id")
AWS_BUCKET = os.getenv("AWS_BUCKET", "my-jitsi-recordings")
AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")

# --- DB CONNECTION ---
conn = psycopg2.connect(
    dbname="video_db",
    user="postgres",
    password="postgres",
    host="localhost",
    cursor_factory=RealDictCursor
)

# --- MODELS ---
class MeetingRequest(BaseModel):
    user_id: str
    user_name: str
    meeting_room: str
    latitude: float
    longitude: float


# --- JWT GENERATOR ---
@app.post("/generate-token")
def generate_token(request: MeetingRequest):
    payload = {
        "aud": "jitsi",
        "iss": JITSI_APP_ID,
        "sub": "meet.jit.si",   # or your self-hosted Jitsi domain
        "room": request.meeting_room,
        "exp": datetime.utcnow() + timedelta(hours=2),
        "context": {
            "user": {
                "id": request.user_id,
                "name": request.user_name
            }
        }
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm="HS256")

    # --- Save metadata in Postgres ---
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO meeting_metadata (user_id, user_name, meeting_room, latitude, longitude, created_at)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (request.user_id, request.user_name, request.meeting_room, request.latitude, request.longitude, datetime.utcnow()))
    conn.commit()

    return {"token": token}


# --- S3 SAVE (Jibri pushes recording -> FastAPI saves metadata) ---
class RecordingCallback(BaseModel):
    meeting_room: str
    s3_key: str

@app.post("/recording-complete")
def recording_complete(data: RecordingCallback):
    s3_url = f"https://{AWS_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{data.s3_key}"

    cur = conn.cursor()
    cur.execute("""
        UPDATE meeting_metadata
        SET recording_url = %s
        WHERE meeting_room = %s
    """, (s3_url, data.meeting_room))
    conn.commit()

    return {"status": "saved", "url": s3_url}