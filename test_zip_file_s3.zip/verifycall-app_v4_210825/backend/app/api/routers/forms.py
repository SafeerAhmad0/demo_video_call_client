from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import insert, select
from app.db.session import get_session
from app.db import models
from app.db.schemas import FormIn, FormOut, EmailRequest
from app.services.pdf import generate_submissions_pdf
from app.services.emailer import send_email_with_attachment
from fastapi.responses import StreamingResponse

router = APIRouter(prefix="/forms", tags=["forms"])

@router.post("", status_code=201)
async def create_form(payload: FormIn, session: AsyncSession = Depends(get_session)):
    stmt = insert(models.FormSubmission).values(
        full_name=payload.full_name,
        email=payload.email,
        notes=payload.notes,
        latitude=payload.latitude,
        longitude=payload.longitude,
        geo_accuracy_m=payload.geo_accuracy_m,
    ).returning(models.FormSubmission.id)
    res = await session.execute(stmt)
    new_id = res.scalar_one()
    await session.commit()
    return {"ok": True, "id": new_id}

@router.get("", response_model=list[FormOut])
async def list_forms(session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(models.FormSubmission).order_by(models.FormSubmission.id))
    items = result.scalars().all()
    return items

@router.get("/pdf")
async def download_pdf(session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(models.FormSubmission))
    items = result.scalars().all()
    data = [
        {
            "id": x.id,
            "full_name": x.full_name,
            "email": x.email,
            "notes": x.notes,
            "latitude": x.latitude,
            "longitude": x.longitude,
            "geo_accuracy_m": x.geo_accuracy_m,
            "captured_at": x.captured_at.isoformat(),
        }
        for x in items
    ]
    pdf_buf = generate_submissions_pdf(data)
    return StreamingResponse(pdf_buf, media_type="application/pdf",
                             headers={"Content-Disposition":"attachment; filename=submissions.pdf"})

@router.post("/send-email")
async def send_email(body: EmailRequest | None = None, session: AsyncSession = Depends(get_session)):
    result = await session.execute(select(models.FormSubmission))
    items = result.scalars().all()
    data = [
        {
            "id": x.id,
            "full_name": x.full_name,
            "email": x.email,
            "notes": x.notes,
            "latitude": x.latitude,
            "longitude": x.longitude,
            "geo_accuracy_m": x.geo_accuracy_m,
            "captured_at": x.captured_at.isoformat(),
        }
        for x in items
    ]
    pdf_buf = generate_submissions_pdf(data)
    send_email_with_attachment(
        subject="Form Submissions Report",
        body="Please find the attached report.",
        pdf_bytes=pdf_buf.read(),
        filename="submissions.pdf",
        to_override=body.to if body and body.to else None
    )
    return {"ok": True}
