from fastapi import APIRouter
from uuid import uuid4
import time, jwt
from app.core.config import settings
from app.db.models import Meeting
from app.db.session import get_session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import insert
from app.db.schemas import NewRoomOut
from fastapi import Depends

router = APIRouter(prefix="/meetings", tags=["meetings"])

def build_jitsi_jwt(room: str) -> str | None:
    # Only if JITSI_APP_ID & JITSI_APP_SECRET are provided (JaaS)
    if not (settings.JITSI_APP_ID and settings.JITSI_APP_SECRET):
        return None
    now = int(time.time())
    payload = {
        "aud": "jitsi",
        "iss": settings.JITSI_APP_ID,
        "sub": settings.JITSI_DOMAIN,       # for JaaS this is your 8x8 subdomain
        "room": room,
        "exp": now + 60 * 60,               # 1 hour
        "nbf": now - 10,
        "context": {"user": {"moderator": True}},
    }
    token = jwt.encode(payload, settings.JITSI_APP_SECRET, algorithm="HS256")
    return token

@router.post("/new-room", response_model=NewRoomOut)
async def new_room(session: AsyncSession = Depends(get_session)):
    room = f"room-{uuid4().hex[:10]}"
    stmt = insert(Meeting).values(room_name=room).returning(Meeting.id)
    await session.execute(stmt)
    await session.commit()
    token = build_jitsi_jwt(room)
    return NewRoomOut(roomName=room, domain=settings.JITSI_DOMAIN, jwt=token)
