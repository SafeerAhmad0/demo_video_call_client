from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert
from app.db.session import get_session
from app.db import models
from app.services.s3 import get_s3, s3_key_for_recording
from app.core.config import settings

router = APIRouter(prefix="/recordings", tags=["recordings"])

@router.post("/upload")
async def upload_recording(
    file: UploadFile = File(...),
    room_name: str = Form(...),
    duration_sec: int | None = Form(None),
    latitude: float | None = Form(None),
    longitude: float | None = Form(None),
    geo_accuracy_m: float | None = Form(None),
    session: AsyncSession = Depends(get_session),
):
    # Find meeting id
    result = await session.execute(select(models.Meeting).where(models.Meeting.room_name == room_name))
    meeting = result.scalar_one_or_none()

    s3 = get_s3()
    key = s3_key_for_recording(file.filename)

    try:
        s3.upload_fileobj(file.file, settings.S3_BUCKET, key, ExtraArgs={"ContentType": file.content_type or "application/octet-stream"})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"S3 upload failed: {e}")

    stmt = insert(models.Recording).values(
        meeting_id=meeting.id if meeting else None,
        s3_key=key,
        mime_type=file.content_type or "application/octet-stream",
        duration_sec=duration_sec,
        latitude=latitude,
        longitude=longitude,
        geo_accuracy_m=geo_accuracy_m,
    ).returning(models.Recording.id)
    res = await session.execute(stmt)
    new_id = res.scalar_one()
    await session.commit()

    return {"ok": True, "recording_id": new_id, "s3_key": key}
