from pydantic import BaseModel, EmailStr
from datetime import datetime

class FormIn(BaseModel):
    full_name: str
    email: EmailStr
    notes: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    geo_accuracy_m: float | None = None

class FormOut(BaseModel):
    id: int
    full_name: str
    email: EmailStr
    notes: str | None
    latitude: float | None
    longitude: float | None
    geo_accuracy_m: float | None
    captured_at: datetime

    class Config:
        from_attributes = True

class NewRoomOut(BaseModel):
    roomName: str
    domain: str
    jwt: str | None = None

class EmailRequest(BaseModel):
    to: EmailStr | None = None  # override default EMAIL_TO if needed
