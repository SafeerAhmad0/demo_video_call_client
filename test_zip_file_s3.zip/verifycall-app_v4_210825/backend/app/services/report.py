from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import io

def generate_pdf(data):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer)
    styles = getSampleStyleSheet()
    story = [
        Paragraph(f"Meeting Report", styles["Title"]),
        Paragraph(f"Name: {data.name}", styles["Normal"]),
        Paragraph(f"Email: {data.email}", styles["Normal"]),
        Paragraph(f"Info: {data.info}", styles["Normal"]),
        Paragraph(f"Location: {data.latitude}, {data.longitude}", styles["Normal"]),
        Paragraph(f"S3 Recording: {data.s3_path}", styles["Normal"]),
    ]
    doc.build(story)
    pdf = buffer.getvalue()
    buffer.close()
    return pdf
