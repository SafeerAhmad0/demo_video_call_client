from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from typing import Iterable

def generate_submissions_pdf(submissions: Iterable[dict]) -> BytesIO:
    buf = BytesIO()
    p = canvas.Canvas(buf, pagesize=A4)
    y = 820
    p.setFont("Helvetica", 11)
    p.drawString(40, 840, "Form Submissions Report")
    p.setFont("Helvetica", 9)

    for s in submissions:
        line1 = f"#{s['id']} | {s['full_name']} | {s['email']}"
        line2 = f"Notes: {s.get('notes','')}"
        line3 = f"Geo: lat={s.get('latitude')} lon={s.get('longitude')} acc={s.get('geo_accuracy_m')}m at {s.get('captured_at')}"
        for line in (line1, line2, line3, " "):
            p.drawString(40, y, line[:110])
            y -= 16
            if y < 60:
                p.showPage(); p.setFont("Helvetica", 9); y = 820
    p.save()
    buf.seek(0)
    return buf
