import smtplib, ssl
from email.message import EmailMessage
from app.core.config import settings

def send_email_with_attachment(subject: str, body: str, pdf_bytes: bytes, filename: str, to_override: str | None = None):
    if not settings.SMTP_HOST:
        raise RuntimeError("SMTP not configured")

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = settings.EMAIL_FROM
    msg["To"] = to_override or settings.EMAIL_TO
    msg.set_content(body)
    msg.add_attachment(pdf_bytes, maintype="application", subtype="pdf", filename=filename)

    context = ssl.create_default_context()
    port = settings.SMTP_PORT or 587
    with smtplib.SMTP(settings.SMTP_HOST, port) as server:
        server.starttls(context=context)
        if settings.SMTP_USER:
            server.login(settings.SMTP_USER, settings.SMTP_PASSWORD or "")
        server.send_message(msg)
