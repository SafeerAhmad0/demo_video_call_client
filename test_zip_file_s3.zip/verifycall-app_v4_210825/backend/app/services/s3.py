import boto3
from botocore.client import Config
from app.core.config import settings
from datetime import datetime

def get_s3():
    return boto3.client(
        "s3",
        region_name=settings.AWS_REGION,
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        config=Config(signature_version="s3v4"),
    )

def s3_key_for_recording(filename: str) -> str:
    ts = datetime.utcnow().strftime("%Y/%m/%d/%H%M%S")
    return f"{settings.S3_PREFIX}{ts}-{filename}"
