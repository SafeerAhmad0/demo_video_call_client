// src/services/api.ts
import axios from "axios";

const API_URL = "http://localhost:8000"; // FastAPI backend URL

export const getFormData = async () => {
  const res = await axios.get(`${API_URL}/form-data`);
  return res.data;
};

export const generatePdf = async (data: any) => {
  const res = await axios.post(`${API_URL}/generate-pdf`, data, {
    responseType: "blob", // important for file download
  });
  return res.data;
};

export const sendEmail = async (data: any) => {
  const res = await axios.post(`${API_URL}/send-email`, data);
  return res.data;
};

import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8000", // FastAPI URL
});

export const getJitsiToken = (room: string, name: string, email: string) =>
  api.post("/meetings/token", { room, name, email });

export const submitForm = (data: any) => api.post("/forms", data);

export default api;