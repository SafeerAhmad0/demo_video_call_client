import React, { useEffect, useState } from "react";
import { JitsiMeeting } from "@jitsi/react-sdk";
import { getJitsiToken } from "../services/api";

export default function Meeting() {
  const [token, setToken] = useState<string | null>(null);
  const room = "claim-room-123";
  const user = { name: "John Doe", email: "john@example.com" };

  useEffect(() => {
    async function fetchToken() {
      const res = await getJitsiToken(room, user.name, user.email);
      setToken(res.data.token);
    }
    fetchToken();
  }, []);

  if (!token) return <p>Loading Jitsi...</p>;

  return (
    <div style={{ height: "100vh", width: "100%" }}>
      <JitsiMeeting
        domain="meet.jitsi"
        roomName={room}
        jwt={token}
        configOverwrite={{ startWithAudioMuted: true }}
        getIFrameRef={(iframeRef) => {
          iframeRef.style.height = "100%";
          iframeRef.style.width = "100%";
        }}
      />
    </div>
  );
}
