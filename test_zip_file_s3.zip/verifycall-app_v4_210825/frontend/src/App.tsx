import { Routes, Route, Navigate } from "react-router-dom"
import Navbar from "./components/Navbar"
import Home from "./pages/Homepage"
import InfoForm from "./pages/Inform"
import FormSubmissions from "./pages/FormSubmissions"
import MultiStepForm from "./pages/MultiStepForm"
import PreviewPage from "./pages/PreviewPage"
import VideoVerification from "./pages/VideoVerification"

export default function App() {
  return (
    <div>
      <Navbar />
      <main style={{ padding: 16 }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/info-form" element={<InfoForm />} />
          <Route path="/preview-page" element={<PreviewPage />} />
          <Route path="/video-verification" element={<VideoVerification />} />
          <Route path="/multi-step-form" element={<MultiStepForm />} />
          <Route path="/submissions" element={<FormSubmissions />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  )
}